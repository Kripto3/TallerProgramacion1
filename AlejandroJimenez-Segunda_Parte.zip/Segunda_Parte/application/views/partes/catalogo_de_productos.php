<section  class="mt-4 page-content">
	<div class="container">
		<div class="alert alert-info text-center pb-4">
			<h3>Mantenimiento</h3>
			<p>Estimados clientes.</p>
			<p>Por temas del <strong>COVID-19</strong> nos encontramos renovando nuestro cat&aacute;logo de art&iacute;culos, ya que nuestros proveedores se encuentran respetando la cuarentena y los envios a nuestra sucursal se encuentran temporalmente pausados.<br>Muchas Gracias !</p>
			<img src="<?php echo base_url('assets/img/logo.png');?>" title="Kripto | Saca el gamer que llevas dentro " height="100"/>
		</div>
	</div>
</section>