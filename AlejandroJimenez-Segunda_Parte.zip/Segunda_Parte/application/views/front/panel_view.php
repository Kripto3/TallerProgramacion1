<section class="mt-4 page-content">
  <div class="container">
    <h1>Panel</h1>
    <div class="well text-justify">
        <h4 style="line-height:1.5";>
        Elija su opcion en el menu de arriba
        </h4>
    </div>
  </div>
</section>
