<section  class="mt-4 page-content">
	<div class="container">
		<h2 class="text-left display-4">Contactos</h3>
		<hr class="my-4 ">
		<div class="container">
		<div class="offset-md-2 col-md-8 ">

		</div>
	</div>
</div>
</section>
<section class="bg-light py-3">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
			<div class="card">
			  <h5 class="card-header">En Corrientes - (Sucursal Principal)</h5>
			  <div class="card-body">
			    <h5 class="card-title">Informaci&oacute;n de Contacto</h5>
			    <ul class="list-unstyled">
			    	<li>Nombre: Alex Jim (Fundador de KRIPTO)</li>
			    	<li>Razon: S.A</li>
			    	<li>Telefonos: 379-444 1111 - 379-444 1122</li>
			    	<li>Domicilio: Caa Guazu 1002</li>
			    	<li>Email: kripto@gmail.com</li>
			    </ul>

			  </div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
			  <h5 class="card-header">En el interior del pais</h5>
			  <div class="card-body">
			    <h5 class="card-title">Informacion de Contacto</h5>
			    <ul class="list-unstyled">
			    	<li>Nombre: KRIPTO - Sucursal</li>
			    	<li>Razon: S.A</li>
			    	<li>Telefonos: 54 9 11-444 1111 - 54 9 11-444 1122</li>
			    	<li>Domicilio: Gdor General 10 - A</li>
			    	<li>Email: kriptosucursal@gmail.com</li>
			    </ul>
			  </div>
			</div>
		</div>
	</div>
</section>