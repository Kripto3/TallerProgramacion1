
    <footer class="w-100 bg-green h-80  py-5">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-3 mb-3 img-center">
    				<a href="<?php echo base_url('principal');?>" title="Kripto | Saca el gamer que llevas dentro !" class="mb-3">
    				 <img src="<?php echo base_url('assets/img/logo.png');?>" height="50"/>
    				</a>
    			</div>
    			<div class="col-md-3 mb-3">
    					<div>
    					   <a class=" text-decoration-none text-white" href="<?php echo base_url('quienes-somos');?>">Quienes Somos</a>
    					</div>
			              <div>
			                 <a class="text-decoration-none text-white" href="<?php echo base_url('comercial');?>">Comercializacion</a>
			              </div>
			              <div>
			                 <a class=" text-decoration-none text-white" href="<?php echo base_url('catalogo');?>">Cat&aacute;logo</a>
			              </div>

    			</div>
    			<div class="col-md-3  mb-3">
    				<div>
              			<a class="text-decoration-none text-white" href="<?php echo base_url('informacion');?>">Contactos</a>
			         </div>
			         <div>
              				<a class="text-decoration-none text-white" href="<?php echo base_url('consultas');?>">Consultas</a>
			              </div>
                                             <div>
                            <a class="text-decoration-none text-white" href="<?php echo base_url('terminos-y-condiciones');?>">Terminos y condiciones</a>
                          </div>

    			</div>
    			<div class="col-md-3 mb-3">
    				<h4 class="text-white">Siguenos en:</h4>
    				<a class="text-decoration-none text-white font-size-20 ml-3" title="Siguenos en Facebook" href="https://www.facebook.com/GM-Kriptonita-Axeso5-432704713595041"><i class="fa fa-facebook-square text-white"></i></a>
    				<a  class="text-decoration-none text-white font-size-20 ml-3" title="siguenos en Instragram"  href="https://www.instagram.com/kriptoop7/"><i class="fa fa-instagram"></i></a>
    				<a  class="text-decoration-none text-white font-size-20 ml-3"  title="siguenos en Youtube" href="https://youtube.com/c/ookriptonitaoo3"><i class="fa fa-youtube"></i></a>
    				
    			</div>
    		</div>
    	</div>
      <script src="<?php echo base_url('assets/js/jquery-3.4.1.js');?>"></script> 
      <script src="<?php echo base_url('assets/js/general.js');?>"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
      <script src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
      <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
      <script src="https://cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"></script>
    </footer>
    <!-- campo opcional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS  -->



  </body>
</html>