<div class="container page-content">
    <div class ="mx-auto alert alert-success mt-4 text-center">
     <h2 class="display-4 " >Compra Exitosa!</h2>
        <i class="fa fa-check-circle fa-4x " aria-hidden="true"></i>
    </div>
</div>
<br>